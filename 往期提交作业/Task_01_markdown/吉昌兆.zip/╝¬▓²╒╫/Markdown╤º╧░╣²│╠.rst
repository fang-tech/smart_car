Markdown学习过程
================

一、基本语法
------------

1. | **标题**
   | #一级标题
   | ##二级标题
   | ...

2. **引用**

      小箭头+内容

3. **列表**

   1. 无序列表

   -  使用方法为“ - ”、“ + ”、“ \* ”后加内容

   -  列表1

   -  列表2

   1. 有序列表

   2. | 嵌套的概念
      | 使用空格

   3. | 任务列表
      | 待办事件

      -  a

      -  b

      -  c

4. | **表格**
   | 表头 + 对齐方式

   ====== ======== ======
   左对齐 居中对齐 右对齐
   ====== ======== ======
   a      b        c
   ====== ======== ======

5. **段落**

   -  换行 —— 两个以上空格后回车 / 空一行

   -  分割线 —— 三个\*

      --------------

   -  字体

      ========== =========
      字体       代码
      ========== =========
      *斜体*     \* \*
      ==高亮==   == ==
      **粗体**   \*\* \*\*
      **斜粗体** **\* \***
      ~~ 删除 ~~ ~~ ~~
      *下划线*   
      ========== =========

   -  | 脚注
      | 脚注使用方法 [1]_

6. **代码**

   .. code:: 

      #include<iostream>
      using namespace std;

7. **链接**

   -  http://baidu.com

   -  `百度 <id>`__

8. | **图片**
   | |image1|

二、拓展语法
------------

1.行内式

``[]``\ 里写链接文字，\ ``()``\ 里写链接地址, ``()``\ 中的 ``""``
中可以为链接指定title属性,
title属性可加可不加。title属性的效果是鼠标悬停在链接上会出现指定的
title文字。\ ``[链接文字](链接地址 "链接标题")``
这样的形式。链接地址与链接标题前有一个空格。

.. code:: markdown

   [Markdown Syntax](https://github.com/cdoco/markdown-syntax)
   [Markdown Syntax](https://github.com/cdoco/markdown-syntax "Markdown Syntax")

2.参考式

参考式链接分为两部分, 文中的写法
``[链接文字][链接标记]``\ ，在文本的任意位置添加
``[链接标记]:链接地址 "链接标题"``, 链接地址与链接标题前有一个空格。

.. code:: markdown

   全球最大的搜索引擎网站是[Google][1]。

   [1]:http://www.google.com "Google"

3.包含引用的列表

如果要在列表项目内放进引用，那 ``>`` 就需要缩进:

4.缩进式多行代码

缩进 4 个空格或是 1 个制表符。

一个代码区块会一直持续到没有缩进的那一行(或是文件结尾)。

.. code:: markdown

       $closure = function () use($name) {
         return $name;
       }

1. LaTeX 公式

$ 表示行内公式

.. code:: markdown

   质能守恒方程可以用一个很简洁的方程式 $E=mc^2$ 来表达。

质能守恒方程可以用一个很简洁的方程式 |image2| 来表达。

$$ 表示整行公式

.. code:: markdown

   $$\sum_{i=1}^n a_i=0$$
   $$f(x_1,x_x,\ldots,x_n) = x_1^2 + x_2^2 + \cdots + x_n^2 $$
   $$\sum^{j-1}_{k=0}{\widehat{\gamma}_{kj} z_k}$$

1. 流程图

   流程图大致分为两段, 第一段是定义元素, 第二段是定义元素之间的走向。

   定义元素的语法 ``tag=>type: content:>url``\ 。

   -  tag就是元素名字。

   -  type是这个元素的类型, 有6中类型,分别为:

   =========== ==========
   type        含义
   =========== ==========
   start       开始
   end         结束
   operation   操作
   subroutine  子程序
   condition   条件
   inputoutput 输入或产出
   =========== ==========

.. [1]
   括号 + ^

.. |image1| image:: https://www.baidu.com/img/bd_logo1.png?where=super
.. |image2| image:: https://latex.codecogs.com/gif.latex?E=mc^2
